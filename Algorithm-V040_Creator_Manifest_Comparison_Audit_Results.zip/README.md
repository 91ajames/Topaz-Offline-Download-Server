# v0.40 positive URL reconciliation against Creator manifests

Source: `/mnt/data/V040_BroadCampaign01.zip` (2,401 HTTP 206 positive URL observations). No complete model body has been downloaded or SHA-256 verified by this campaign.

## Baselines

- Earlier preserved Creator manifest snapshot from `2026-11-05 (2).zip`: 14 manifests, 4,249 logical entries, 4,076 unique physical records. **463 basenames not in this snapshot, across 902 successful URLs.** This archive is not claimed to be byte-identical to the released 7.0.3 Creator snapshot.
- Later b4 Creator manifest snapshot from `build264-b4-review.zip`: 14 manifests, 4,285 logical entries, 4,112 unique physical records. **427 basenames not in b4, across 866 successful URLs.** The 36-basename difference reflects added `VIDEO_1.6.1` entries.

## Exactly 2,401 results versus b4

- 866 successful URLs have 427 distinct basenames not in b4.
- 1,196 successful URLs have the identical Creator-relative path and reported model size, but another host.
- 303 successful URLs share a Creator-known basename but use a different path; 184 match a pinned size for that basename, 119 do not (40 different names). These 303 must not automatically be treated as equivalent aliases.
- 36 successful URLs are exact canonical Creator URLs recorded in b4.

Thus, **1,499 are candidate alternate URLs for Creator-known filenames** (1,196 stronger same-path routes + 303 path variants). None was SHA-256 validated in this campaign. The 1,196 paths match the Creator-pinned size; this still does not prove byte equivalence.

## Reported size discrepancies

- Five distinct basenames have two different HTTP `Content-Range` total sizes within the campaign: slb-v1-fp16-512x512-ox.tz, sll-v1-fp16-512x512-ml.tz, sll-v1-fp16-512x512-ox.tz, sll-v1-fp32-512x512-ox.tz, sll-v1-fp32-512x512-tf.tz.
- Separately, 119 alternate-path HTTP 206 routes across 40 basenames differ in reported size from every b4 Creator-pinned size for that basename.

The 294 basenames from the earlier independent audit are those absent from the **historical research inventory**, which is a different comparison set. They must not be confused with the Creator comparison counts.
